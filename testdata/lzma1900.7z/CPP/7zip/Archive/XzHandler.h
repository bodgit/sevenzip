// XzHandler.h

#ifndef __XZ_HANDLER_H
#define __XZ_HANDLER_H

namespace NArchive {
namespace NXz {
 
}}

#endif
